<?php
$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'pb_imagi';

$koneksi = mysqli_connect($host, $nama, $pass, $db);

